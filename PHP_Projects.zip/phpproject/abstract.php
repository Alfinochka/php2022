<?php

abstract class Transport{
    protected $name;
    public function __construct($name){
        $this->name = $name;
    }
    abstract public function move();
}

class Bike extends Transport{
    public function move(){
        echo $this->name." move forward \r\n";
    }
}

$t = new Bike("Yamaha");
$t->move();