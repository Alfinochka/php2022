<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Action</title>
</head>
<body>
    <form action="" method="post">
        Enter your name:
        <input type="text" name="name" id=""><br>
        Enter your age:
        <input type="text" name="age" id=""><br>
        <input type="submit" value="Подтвердить" name="send">
    </form>
    <?php
    if(isset($_POST['send'])):
        echo "Меня зовут ";
        echo $_POST['name'];
        echo ", мой возраст:";
        echo $_POST['age'];
    endif;
    ?>
</body>
</html>