<?
    require_once $_SERVER['DOCUMENT_ROOT'].'/lib/model_article.php';
    $obArticles = new Model_Article();
    $arItems = $obArticles->getList();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Articles</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <? if(isset($_GET['ID']) && $_GET['ID'] > 0): ?>
            <?
                $obItem = new Model_Article($_GET['ID']);
                $arItem = $obItem->asArray();
                ?>
                <h1><?=$obItem->NAME?></h1>
                <div><em><?=implode('.',array_reverse(explode('-',$obItem->DATE)))?></em></div>
                <div><?=$obItem->TEXT?></div>
        <? else: ?>
            <div class="row">
                <? if($arItems): ?>
                    <? foreach($obArticles as $arItem): ?>
                        <a class="col-6" href="?ID=<?=$arItem['ID']?>">
                            <div><?=$arItem['DATE']?></div>
                            <div><?=$arItem['TEXT']?></div>
                        </a>
                    <? endforeach; ?>
                <? else: ?>
                <? endif; ?>
            </div>
        <? endif; ?>

    </div>    
</body>
</html>