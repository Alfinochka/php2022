<?php
$date = new DateTime();
echo $date->format("d.m.Y H:i:s")."\r\n";
// echo $date->format(DateTimeInterface::W3C)."\r\n";

$date->modify('+2 hours');
echo $date->format("d.m.Y H:i:s")."\r\n";

$date->setDate(2012,12,22)->setTime(8,8,0);
echo $date->format("d.m.Y H:i:s")."\r\n";

$date_input = "16/10/2015";
$date_object = DateTime::createFromFormat("d/m/Y",$date_input);
echo"\r\n";
// print_r($date_object);
if($date_object){
    echo "Format is right \r\n";
}else{
    echo "Format is wrong \r\n";
}

$date_common = DateTime::createFromFormat(
    "Y-m-d H:i:s",
    "2015-05-09 01:00:00",
    new DateTimeZone("Europe/Moscow")
);
echo $date_common->format("H:i:s")."\r\n";
$date_common->setTimeZone( new DateTimeZone('Asia/Yekaterinburg') );
echo $date_common->format("H:i:s")."\r\n";

// var_dump($date_common);
