<?php

function printAge($age){
    $age = intval($age);
    if($age < 0){
        // trigger_error("Возраст не может быть отрицательным",E_USER_ERROR);
        error_log("Возраст не может быть отрицательным\r\n\r\n",3,'err.log');
        return;
    }
    echo "Возраст: $age \r\n";
}
printAge(-10);