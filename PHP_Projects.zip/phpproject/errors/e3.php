<?php
// error_reporting(E_ALL);
// ini_set('error_log','err.log');
// ini_set('log_errors',true);
// ini_set('display_errors',false);
// error_reporting(E_ALL);

// set_error_handler(function($n, $message, $file, $line){
//     echo "ER: ".error_reporting()."\r\n";
//     echo "Ошибка #$n: $message \r\n".
//     "В файле $file #$line";
//     $stack = debug_backtrace();
//     print_r($stack);
// },E_ALL);
// error_log("Begin\r\n");
echo"Start \r\n";

class mySuperClass{
    public function __construct(){}
    public function __destruct(){
        echo __CLASS__." was dead \r\n";
    }
}

function one($v){
    echo "function ".__METHOD__." start\r\n";
    two($v * $v);
    echo "function ".__METHOD__." end\r\n";
}
function two($v){
    echo "function ".__METHOD__." start\r\n";
    $msc = new mySuperClass();
    three($v / 2);
    echo "function ".__METHOD__." end\r\n";
}
function three(){
    echo "function ".__METHOD__." start\r\n";
    // $stack = debug_backtrace();
    // print_r($stack);
    echo ["16"] / 8;
    echo "function ".__METHOD__." end\r\n";
}
try{
    one(2);
}catch(Exception $e){
    echo "Исключение \r\n";
}catch(Error $e){
    echo "Ошибка \r\n";
    print_r(debug_backtrace());
}


echo"End \r\n";