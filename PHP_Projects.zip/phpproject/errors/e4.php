<?php

echo "Begin \r\n";
try{
    echo"Всё на свете имеет начало... ";
    throw new Exception("hello world \r\n");
    echo"и всё имеет конец \r\n";
}catch(Exception $e){
    echo "Исключение: {$e->getMessage()}";
}

echo "End \r\n";