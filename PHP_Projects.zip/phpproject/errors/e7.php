<?php
class HeadShotException extends Exception{}
function eatThis(){
    throw new HeadShotException("Babg! \r\n");
}
function action(){
    echo "Всё имеет начало";
    try{
        eatThis();
    }catch(Exception $e){
        echo " и имеет конец. \r\n";
        throw $e;
    }
}

try{
    action();
}catch(HeadShotException $e){
    echo "Вы застрелились {$e->getMessage()}";
}