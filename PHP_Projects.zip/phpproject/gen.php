<?php
function simple($from=0, $to=100){
    for($i=$from; $i<$to; $i++){
        yield $i;
    }
}

$gen = simple(1,5);

print_r($gen);

foreach($gen as $item){
    echo"$item \r\n";
}