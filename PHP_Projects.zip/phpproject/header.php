<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="<?=metaData('Keywords')?>">
    <meta name="description" content="<?=metaData('description')?>">
    <title><?=metaData('title')?></title>
    <style>
        .menuitem.active{
            background: #AAA;
        }
    </style>
</head>
<body>
    <?
    $arMenu = array(
        ['LINK'=>'/','NAME'=>'Главная'],
        ['LINK'=>'/articles','NAME'=>'Статьи'],
        ['LINK'=>'/news','NAME'=>'Новости'],
        ['LINK'=>'/contacts','NAME'=>'Контакты'],
        ['LINK'=>'/regions','NAME'=>'Регионы'],
    );
    ?>
    <ul>
        <?
        foreach($arMenu as $arMenuItem){
            $class = 'menuitem';
            $classList = [
                'menuitem'=> true,
                'active'=> ($arMenuItem['LINK'] == $_SERVER['REQUEST_URI']),
            ];
            $classList = array_filter($classList, fn($el) => $el);
            $className = implode(' ',array_keys($classList));
            if($arMenuItem['LINK'] == $_SERVER['REQUEST_URI']) $class.=" active";
            //print_r($classList);
            echo"<li class=\"$className\"><a href=\"{$arMenuItem['LINK']}\">{$arMenuItem['NAME']}</a></li>\n\t";
        }
        ?>
    </ul>
    <?
    
    ?>