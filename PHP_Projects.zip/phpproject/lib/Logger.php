<?php 
if(empty($_SERVER['DOCUMENT_ROOT'])) $_SERVER['DOCUMENT_ROOT'] = __DIR__;

class MyLogger{
    private $name;
    private $buffer='';
    public static $var="555";
    public function __construct($name){
        $this->name = $name;
    }
    public function log($data){
        // $this->buffer.="##\r\n# ".date('Y-m-d H:i:s')."\r\n##\r\n\r\n";
        $this->buffer.=print_r($data,true)."\r\n\r\n";
    }
    public function __destruct(){
        $dirpath = $_SERVER['DOCUMENT_ROOT'].'/log';
        if(!file_exists($dirpath)) mkdir($dirpath,0775,true);
        // echo "$dirpath \r\n";
        $filepath = $dirpath.'/'.$this->name.'.log';
        $f = fopen($filepath, 'a');
        fputs($f,"##\r\n# ".date('Y-m-d H:i:s')."\r\n##\r\n\r\n");
        fputs($f,$this->buffer);
        // fputs($f,self::$var);
        fclose($f);
    }
}

class Debugger extends MyLogger{
    // public $logger;
    protected $somevar;
    public function __construct($name, $somevar){
        $this->somevar = $somevar;
        parent::__construct($name);
        // $this->logger = new MyLogger($name);
    }
    protected $name;
    public function log($data){
        $stack = debug_backtrace();
        // $this->logger->log($stack);
        parent::log($stack[0]['file']." #".$stack[0]['line']);
        parent::log($data);
    }
}

// $d = new Debugger('newlog');
// $d->log('some data');

// $logger = new Debugger('superlog');

function mySiperLog($data, MyLogger $logger){
    $logger->log($data);
}

// mySiperLog('some data',$logger);


class Controller{
    public function before(){}
    public function after(){}
}

class Controller_Home extends Controller{
    public function before(){
        parent::before();
        /* some actions */
    }
    /** some methods */
    public function after(){
        /* some actions */
        parent::after();
    }
}

class Controller_Wellcome extends Controller_Home{
    public function before(){
        parent::before();
        /* some actions */
    }
}


// $ch = new Controller_Wellcome();

print_r( new class {
    public $title;
    public function __construct(){
        $this->title = "Hello world!";
    }
 });
