<?php
namespace PHP8;

function strlen($str){
    return \strlen($str) / 2;
}

class Page{
    public function __construct(){
        echo"i am page \r\n";
    }
}