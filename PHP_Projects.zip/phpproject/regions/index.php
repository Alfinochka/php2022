<? include_once $_SERVER['DOCUMENT_ROOT']."/func.php";?>
<?
    metaData('title',"Регионы РФ");
?>
<? include  $_SERVER['DOCUMENT_ROOT']."/header.php" ?>
<?
    $jsonData = file_get_contents($_SERVER['DOCUMENT_ROOT'].'/data/regions.json');
    $rawData = json_decode($jsonData,true);
    $arDistricts = array_map(function($el){ return $el['district']; },$rawData);
    $arDistricts = array_unique($arDistricts);
    $arDistricts = array_values($arDistricts);
    // print_r($rawData);
    //print_r($arDistricts);
    $cpop = array_sum( array_column($rawData, 'population') );
    foreach($arDistricts as $sDistrict):
        $dpop = 0;
        $arItems = array_filter($rawData,function($arItem) use($sDistrict){
            return $arItem['district'] == $sDistrict;
        });
        foreach($arItems as $arItem) $dpop+=$arItem['population'];
        echo "<h2>$sDistrict (".number_format($dpop,0,'',' ').")</h2>";


        $arSubjects = array_values(array_unique(array_column($arItems,'subject')));
        sort($arSubjects);
        foreach($arSubjects as $sSubject){
            $arSubItems = array_filter($arItems, function($arItem) use ($sSubject){return $arItem['subject'] == $sSubject;});
            usort($arSubItems, fn($a,$b) => -($a['population'] <=> $b['population']));
        $pop = 0;
        foreach($arSubItems as $arItem) $pop+=$arItem['population'];
            ?>
            <h3><?=$sSubject?></h3>
<table border="1">
    <thead>
        <th>Имя</th>
        <th>Округ</th>
        <th>Субъект</th>
        <th>Население</th>
    </thead>
    <tfoot>
        <td colspan="3">Всего</td>
        <td><?=number_format($pop,0,'.',' ')?></td>
    </tfoot>
    <tbody>
        <? foreach($arSubItems as $arItem): ?>
            <? $hasMillion = ($arItem['population'] > 1e6); ?>
            <tr data-m="<?=$hasMillion?>">
                <td><?=$arItem['name']?></td>
                <td><?=$arItem['district']?></td>
                <td><?=$arItem['subject']?></td>
                <td><?=number_format($arItem['population'],0,'.',' ')?></td>
            </tr>
        <? endforeach; ?>
    </tbody>
</table>
        <?}

        // print_r($arSubjects);
        ?>

        <?
    endforeach;
    echo"<h4>Всего в стране: ".number_format($cpop,0,""," ")."</h4>"
?>
<style>
    tr[data-m="1"] > td:last-child{
        background-color: #dba9db;
    }
</style>

<? include  $_SERVER['DOCUMENT_ROOT']."/footer.php" ?>