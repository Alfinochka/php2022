<?php

$date = $date_common = DateTime::createFromFormat(
    "Y-m-d H:i:s",
    "2021-01-01 01:00:00");
$date_now = new DateTime();
$di = $date_interval = $date_now->diff($date);


print_r($date_interval);

echo"Между ".$date->format("Y-m-d")." ";
echo"и ".$date_now->format("Y-m-d")." \r\n";
echo"лет - {$di->y}, месяцев - {$di->m}, дней - {$di->d}\r\n";

$interval = new DateInterval("P5Y10M2DT3H9M1S");

$date_now->add($interval);
echo"Через 5 лет 10 мес... ".$date_now->format("Y-m-d")." \r\n";

// print_r($interval);

$now = new DateTime();
$now->setTimeZone( new DateTimeZone('Asia/Yekaterinburg') );
// print_r($now);
$step = new DateInterval('P1W');
$period = new DatePeriod($now, $step, 5);
// print_r($period);
foreach($period as $periodic){
    // print_r($periodic);
    echo $periodic->format("Y-m-d")."\r\n";
}