<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Timezones</title>
</head>
<body>
    <?
    $data = [
        ["NAME"=>"Калининград","TZ"=>'Europe/Kaliningrad'],
        ["NAME"=>"Москва","TZ"=>"Europe/Moscow"],
        ["NAME"=>"Самара","TZ"=>'Europe/Samara'],
        ["NAME"=>"Екатеринбург","TZ"=>'Asia/Yekaterinburg'],
        ["NAME"=>"Омск","TZ"=>"Asia/Omsk"],
    ];
    $now = new DateTime();
    foreach($data as $i=>$item){
        $now->setTimeZone( new DateTimeZone($item['TZ']) );
        $data[$i]['TIME']=$now->format("H:i:s");
    }
    ?>
    <table border="1" align="center">
        <? foreach($data as $item): ?>
            <tr>
                <td><?=$item['NAME']?></td>
                <td><?=$item['TIME']?></td>
            </tr>
        <? endforeach; ?>
    </table>
</body>
</html>