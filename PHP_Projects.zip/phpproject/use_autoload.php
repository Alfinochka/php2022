<?php
if(empty($_SERVER['DOCUMENT_ROOT'])) $_SERVER['DOCUMENT_ROOT'] = __DIR__;

spl_autoload_register(function($name){
    require_once $_SERVER['DOCUMENT_ROOT']."/classes/$name.php";
});

$u = new User("Peter",'admin');
print_r($u);

$p = new Page("Main","Long Long text....");
print_r($p);


abstract class Controller{}
class Controller_Home extends Controller{} //  /Controller/Home.php
class Controller_Admin_Index extends Controller{} // /Controller/Admin/Index.php
