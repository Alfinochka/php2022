<?php

class Controller_Welcome extends Controller_Base {

	public function action_index()
	{
		$this->template->title = "Hello world!";
		$this->template->h1 = "Ура, заработало!";
		
	}

} // End Welcome
