<?php

interface Cache_Arithmetic extends Kohana_Cache_Arithmetic {}