<?php

interface Cache_GarbageCollect extends Kohana_Cache_GarbageCollect {}