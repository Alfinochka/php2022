<?php

class Cache_Wincache extends Kohana_Cache_Wincache {}