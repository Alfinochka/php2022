<?php

class Codebench extends Kohana_Codebench {}