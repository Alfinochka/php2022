<?php

abstract class Database extends Kohana_Database {}
