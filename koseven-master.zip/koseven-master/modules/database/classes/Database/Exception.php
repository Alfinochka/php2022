<?php

class Database_Exception extends Kohana_Database_Exception {}
