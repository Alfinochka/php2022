<?php

class Database_MySQLi extends Kohana_Database_MySQLi {}
