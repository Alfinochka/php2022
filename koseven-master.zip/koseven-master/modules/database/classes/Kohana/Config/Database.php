<?php

/**
 * Backwards compatibility extension for the database writer.
 *
 * @package    Kohana/Database
 * @category   Configuration
 * @author     Kohana Team
 * @copyright  (c) Kohana Team
 * @license    https://koseven.ga/LICENSE.md
 */
class Kohana_Config_Database extends Config_Database_Writer
{

}
