<?php
/**
 * Database exceptions.
 *
 * @package    Kohana/Database
 * @category   Exceptions
 * @author     Kohana Team
 * @copyright  (c) Kohana Team
 * @license    https://koseven.ga/LICENSE.md
 */
class Kohana_Database_Exception extends Kohana_Exception {}
