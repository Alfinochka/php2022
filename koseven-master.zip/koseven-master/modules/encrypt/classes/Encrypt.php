<?php

class Encrypt extends Kohana_Encrypt {}
