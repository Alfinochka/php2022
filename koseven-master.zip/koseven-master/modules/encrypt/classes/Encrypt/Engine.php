<?php

abstract class Encrypt_Engine extends Kohana_Encrypt_Engine {}
