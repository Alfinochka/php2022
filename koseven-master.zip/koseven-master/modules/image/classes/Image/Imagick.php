<?php

class Image_Imagick extends Kohana_Image_Imagick {}
