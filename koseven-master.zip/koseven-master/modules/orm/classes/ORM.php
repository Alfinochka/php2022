<?php

class ORM extends Kohana_ORM {}
