<?php

class Unittest_Helpers extends Kohana_Unittest_Helpers {}
