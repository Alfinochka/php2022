<?php

class Unittest_TestSuite extends Kohana_Unittest_TestSuite {}
