<?php

class Unittest_Tests extends Kohana_Unittest_Tests {}
