<?php

class Controller_Userguide extends Kohana_Controller_Userguide {}
