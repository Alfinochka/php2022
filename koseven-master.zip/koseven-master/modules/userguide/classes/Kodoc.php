<?php

class Kodoc extends Kohana_Kodoc {}
