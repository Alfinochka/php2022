<?php

class Kodoc_Markdown extends Kohana_Kodoc_Markdown {}
