<?php

class Kodoc_Method extends Kohana_Kodoc_Method {} 