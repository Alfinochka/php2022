<?php

class Kodoc_Method_Param extends Kohana_Kodoc_Method_Param {}
