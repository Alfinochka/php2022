<?php

class Kodoc_Property extends Kohana_Kodoc_Property {}
