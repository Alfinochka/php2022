# Kohana PHP Framework - core

This is the core package for the [Kohana](http://kohanaframework.org/) object oriented HMVC framework built using PHP5.
It aims to be swift, secure, and small.

Released under a [BSD license](http://kohanaframework.org/license), Kohana can be used legally for any open source,
commercial, or personal project.
