<?php

class Arr extends Kohana_Arr {}
