<?php

class Config extends Kohana_Config {}
