<?php

class Config_File extends Kohana_Config_File {}
