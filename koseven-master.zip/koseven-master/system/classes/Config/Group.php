<?php

class Config_Group extends Kohana_Config_Group {}
