<?php

abstract class Controller extends Kohana_Controller {}
