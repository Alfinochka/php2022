<?php

class Cookie extends Kohana_Cookie {}
