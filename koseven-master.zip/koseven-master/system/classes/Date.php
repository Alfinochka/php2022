<?php

class Date extends Kohana_Date {}
