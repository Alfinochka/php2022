<?php

class Debug extends Kohana_Debug {}
