<?php

class Feed extends Kohana_Feed {}
