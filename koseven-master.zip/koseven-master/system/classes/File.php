<?php

class File extends Kohana_File {}
