<?php

class Form extends Kohana_Form {}
