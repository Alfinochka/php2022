<?php

class Fragment extends Kohana_Fragment {}
