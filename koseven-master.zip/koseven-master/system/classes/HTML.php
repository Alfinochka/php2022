<?php

class HTML extends Kohana_HTML {}
