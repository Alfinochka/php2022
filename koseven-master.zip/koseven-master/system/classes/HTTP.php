<?php

abstract class HTTP extends Kohana_HTTP {}
