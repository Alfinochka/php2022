<?php

class HTTP_Exception extends Kohana_HTTP_Exception {}
