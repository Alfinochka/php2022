<?php

class HTTP_Exception_302 extends Kohana_HTTP_Exception_302 {}
