<?php

class HTTP_Exception_303 extends Kohana_HTTP_Exception_303 {}
