<?php

class HTTP_Exception_305 extends Kohana_HTTP_Exception_305 {}
