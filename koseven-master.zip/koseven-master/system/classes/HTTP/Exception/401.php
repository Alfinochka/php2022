<?php

class HTTP_Exception_401 extends Kohana_HTTP_Exception_401 {}
