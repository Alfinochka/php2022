<?php

class HTTP_Exception_402 extends Kohana_HTTP_Exception_402 {}
