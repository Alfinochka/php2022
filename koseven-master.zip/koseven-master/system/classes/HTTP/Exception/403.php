<?php

class HTTP_Exception_403 extends Kohana_HTTP_Exception_403 {}
