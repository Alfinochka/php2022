<?php

class HTTP_Exception_406 extends Kohana_HTTP_Exception_406 {}
