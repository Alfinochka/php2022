<?php

class HTTP_Exception_408 extends Kohana_HTTP_Exception_408 {}
