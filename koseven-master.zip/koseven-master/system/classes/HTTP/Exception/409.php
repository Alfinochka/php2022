<?php

class HTTP_Exception_409 extends Kohana_HTTP_Exception_409 {}
