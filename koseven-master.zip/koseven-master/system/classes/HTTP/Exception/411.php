<?php

class HTTP_Exception_411 extends Kohana_HTTP_Exception_411 {}
