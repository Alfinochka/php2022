<?php

class HTTP_Exception_412 extends Kohana_HTTP_Exception_412 {}
