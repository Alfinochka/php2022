<?php

class HTTP_Exception_413 extends Kohana_HTTP_Exception_413 {}
