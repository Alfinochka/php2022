<?php

class HTTP_Exception_414 extends Kohana_HTTP_Exception_414 {}
