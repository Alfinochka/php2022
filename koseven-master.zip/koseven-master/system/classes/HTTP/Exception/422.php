<?php

class HTTP_Exception_422 extends Kohana_HTTP_Exception_422 {}
