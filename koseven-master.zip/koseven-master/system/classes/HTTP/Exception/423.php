<?php

class HTTP_Exception_423 extends Kohana_HTTP_Exception_423 {}
