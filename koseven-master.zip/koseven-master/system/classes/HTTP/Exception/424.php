<?php

class HTTP_Exception_424 extends Kohana_HTTP_Exception_424 {}
