<?php

class HTTP_Exception_429 extends Kohana_HTTP_Exception_429 {}
