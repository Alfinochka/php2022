<?php

class HTTP_Exception_501 extends Kohana_HTTP_Exception_501 {}
