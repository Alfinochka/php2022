<?php

class HTTP_Exception_507 extends Kohana_HTTP_Exception_507 {}
