<?php

class HTTP_Exception_508 extends Kohana_HTTP_Exception_508 {}
