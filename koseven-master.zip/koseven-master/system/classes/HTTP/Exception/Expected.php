<?php

abstract class HTTP_Exception_Expected extends Kohana_HTTP_Exception_Expected {}
