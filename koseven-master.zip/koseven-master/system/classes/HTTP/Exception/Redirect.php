<?php

abstract class HTTP_Exception_Redirect extends Kohana_HTTP_Exception_Redirect {}
