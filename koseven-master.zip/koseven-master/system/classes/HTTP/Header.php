<?php

class HTTP_Header extends Kohana_HTTP_Header {}
