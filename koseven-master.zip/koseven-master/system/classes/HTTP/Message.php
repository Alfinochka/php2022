<?php

interface HTTP_Message extends Kohana_HTTP_Message {}
