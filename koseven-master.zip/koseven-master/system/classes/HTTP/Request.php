<?php

interface HTTP_Request extends Kohana_HTTP_Request {}
