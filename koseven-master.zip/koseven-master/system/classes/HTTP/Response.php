<?php

interface HTTP_Response extends Kohana_HTTP_Response {}
