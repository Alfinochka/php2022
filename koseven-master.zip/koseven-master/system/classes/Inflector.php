<?php

class Inflector extends Kohana_Inflector {}
