<?php

class Kohana extends Kohana_Core {}
