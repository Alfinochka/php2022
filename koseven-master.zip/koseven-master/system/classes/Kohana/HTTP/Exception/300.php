<?php

class Kohana_HTTP_Exception_300 extends HTTP_Exception_Redirect {

	/**
	 * @var   integer    HTTP 300 Multiple Choices
	 */
	protected $_code = 300;

}
