<?php

class Kohana_HTTP_Exception_417 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 417 Expectation Failed
	 */
	protected $_code = 417;

}
