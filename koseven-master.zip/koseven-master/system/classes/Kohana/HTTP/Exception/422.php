<?php

class Kohana_HTTP_Exception_422 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 422 Unprocessable Entity
	 */
	protected $_code = 422;

}
