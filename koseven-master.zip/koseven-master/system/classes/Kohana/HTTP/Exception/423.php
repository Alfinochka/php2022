<?php

class Kohana_HTTP_Exception_423 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 423 Locked
	 */
	protected $_code = 423;

}
