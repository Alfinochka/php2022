<?php

class Kohana_HTTP_Exception_424 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 424 Failed Dependency
	 */
	protected $_code = 424;

}
