<?php

class Kohana_HTTP_Exception_507 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 507 Insufficient Storage
	 */
	protected $_code = 507;

}
