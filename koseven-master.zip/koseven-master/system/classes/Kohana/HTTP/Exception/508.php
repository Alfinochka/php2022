<?php

class Kohana_HTTP_Exception_508 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 508 Loop Detected
	 */
	protected $_code = 508;

}
