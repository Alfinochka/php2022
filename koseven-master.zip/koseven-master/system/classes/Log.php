<?php

class Log extends Kohana_Log {}
