<?php

class Log_File extends Kohana_Log_File {}
