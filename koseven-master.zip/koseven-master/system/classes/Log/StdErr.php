<?php

class Log_StdErr extends Kohana_Log_StdErr {}
