<?php

class Log_StdOut extends Kohana_Log_StdOut {}
