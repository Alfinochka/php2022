<?php

class Log_Syslog extends Kohana_Log_Syslog {}
