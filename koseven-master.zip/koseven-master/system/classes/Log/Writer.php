<?php

abstract class Log_Writer extends Kohana_Log_Writer {}
