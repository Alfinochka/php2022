<?php

abstract class Model extends Kohana_Model {}
