<?php

class Num extends Kohana_Num {}
