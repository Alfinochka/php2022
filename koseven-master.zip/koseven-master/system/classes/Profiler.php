<?php

class Profiler extends Kohana_Profiler {}
