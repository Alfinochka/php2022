<?php

class Request extends Kohana_Request {}
