<?php

abstract class Request_Client extends Kohana_Request_Client {}
