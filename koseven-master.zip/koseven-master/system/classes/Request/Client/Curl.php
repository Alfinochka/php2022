<?php

class Request_Client_Curl extends Kohana_Request_Client_Curl {}
