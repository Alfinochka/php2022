<? include_once $_SERVER['DOCUMENT_ROOT']."/func.php";?>
<?
    metaData('title',"Счета");
?>
<? include  $_SERVER['DOCUMENT_ROOT']."/header.php" ?>
<?
    $accounts = [
        ['DATE'=>'2021-01-12','AMOUNT'=>146],
        ['DATE'=>'2022-01-12','AMOUNT'=>-90],
        ['DATE'=>'2021-11-12','AMOUNT'=>1024],
        ['DATE'=>'2021-05-09','AMOUNT'=>999],
        ['DATE'=>'2022-12-14','AMOUNT'=>8500],
        ['DATE'=>'2022-08-18','AMOUNT'=>3200],
        ['DATE'=>'2022-06-10','AMOUNT'=>-5000],
        ['DATE'=>'2022-05-20','AMOUNT'=>1000],
        ['DATE'=>'2021-01-12','AMOUNT'=>-250],
        ['DATE'=>'2022-09-15','AMOUNT'=>4000],
        ['DATE'=>'2021-01-01','AMOUNT'=>146],
    ];
    array_walk($accounts, function(&$item){
        $item["COLOR"] = ($item['AMOUNT']>0) ? "black" : "red";
    });
    usort($accounts, function($a, $b){
        $ax = $a['AMOUNT'] <=> 0; // -1,1
        $bx = $b['AMOUNT'] <=> 0; // -1,1
        if($ax != $bx) return $ax <=> $bx;
        // else
        return -($a['DATE'] <=> $b['DATE']);
    });
    //print_r($accounts);
?>
<table border="1">
    <thead>
        <th>Дата</th>
        <th>Cумма</th>
    </thead>
    <tbody>
        <? foreach($accounts as $item): ?>
            <tr>
                <td><?=$item['DATE']?></td>
                <td style="color:<?=$item["COLOR"]?>"><?=$item['AMOUNT']?></td>
            </tr>
        <? endforeach; ?>
    </tbody>
</table>



<? include  $_SERVER['DOCUMENT_ROOT']."/footer.php" ?>