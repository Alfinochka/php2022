<?
    require_once $_SERVER['DOCUMENT_ROOT'].'/lib/model_article.php';
    $obArticles = new Model_Article();
    $arItems = $obArticles->getList();
    usort($arItems,fn($a,$b)=>-($a['DATE'] <=> $b['DATE']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <h1>News Admin</h1>
        <? if(isset($_GET['ID'])): ?>
            <?
            $obItem = new Model_Article($_GET['ID']);
            $arItem = $obItem->asArray();
            print_r($arItem);
            if(isset($_POST['save'])){
                //print_r($_POST['ITEM']);
                $obItem->putItem($_POST['ITEM']);
                // if(ob_get_contents()) ob_end_flush();
                // header("Location:/articles/admin.php");
                echo"<script>window.location='/articles/admin.php'</script>";
            }
            ?>
            <form action="" method="post">
                <?if($arItem['ID']):?><input type="hidden" name="ITEM[ID]" value="<?=$arItem['ID']?>"><?endif;?>
                <table class="table">
                    <tr>
                        <th>Дата</th>
                        <td><input type="date" name="ITEM[DATE]" value="<?=$arItem['DATE']?>" id=""></td>
                    </tr>
                    <tr>
                        <th>Заголовок</th>
                        <td><input type="text" name="ITEM[NAME]" value="<?=$arItem['NAME']?>" id=""></td>
                    </tr>
                    <tr>
                        <th>Текст</th>
                        <td>
                            <textarea name="ITEM[TEXT]" id="" cols="30" rows="10"><?=htmlspecialchars($arItem['TEXT'] ?? '')?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <input type="submit" value="Сохранить" class="btn btn-success" name="save">
                        </td>
                    </tr>
                </table>
            </form>
        <? else: ?>
            <? if($arItems): ?>
                <!-- <pre>
                <? print_r($arItems); ?>
                </pre> -->
                <table class="table">
                    <? foreach($arItems as $arItem): ?>
                        <tr>
                            <!-- <td><?=$arItem['ID']?></td> -->
                            <td><?=$arItem['NAME']?></td>
                            <td><?=$arItem['DATE']?></td>
                            <td>
                                <a href="?ID=<?=$arItem['ID']?>">edit</a>
                            </td>
                        </tr>
                    <? endforeach ?>
                </table>
            <? else: ?>
                <h2>Нет новостей</h2>
            <? endif; ?>
            <a href="?ID=0" class="btn btn-primary">Добавить</a>
        <? endif; ?>
    </div>
</body>
</html>