<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendar 2023</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <?
    function getCalendarData($year = null, $month = null){
        $year = $year ?? date('Y');
        $month = $month ?? date('m') * 1;

        $fmd_ts = mktime(0,0,0,$month,1,$year);//$firstDayOfMonth
        $fdw = date("N",$fmd_ts)-1; // weekDayOfFirst Day
        $mdt = date("t",$fmd_ts);// month day total
        // echo"fdw: $fdw \n";
        // echo"mdt: $mdt \n";
        $arResult = [];
        $wi = 0;
        $arResult[$wi] = array_fill(0,$fdw,"");
        
        for($i = 1; $i<=$mdt; $i++){
            $arResult[$wi][] = $i;
            if(sizeOf($arResult[$wi]) == 7) $wi++;
        }

        return $arResult;
    }

    function printCalendar($year = null, $month = null){
        $year = $year ?? date('Y');
        $month = $month ?? date('m') * 1;
        $month_cur = date('m') * 1;
        $day_cur = date('d') * 1;

        $months = array( 1 => 'Январь' , 'Февраль' , 'Март' , 'Апрель' , 'Май' , 'Июнь' , 'Июль' , 'Август' , 'Сентябрь' , 'Октябрь' , 'Ноябрь' , 'Декабрь' );
        $wdays = ["Пн","Вт","Ср","Чт","Пт","Сб","Вс"];
        $data = getCalendarData($year, $month);
        $html='<table class="table">';
        $html.='<thead class="thead thead-dark">';
        $html.='<tr><th colspan="7">'.$months[$month].' '.$year.'</th></tr>';
        // $html.='<tr>'.implode('',array_map(function($wd){ return"<th>$wd</th>"; },$wdays)).'</tr>';
        $html.='<tr>'.implode('',array_map(fn($wd) => "<th>$wd</th>" ,$wdays)).'</tr>';
        $html.='</thead>';
        $html.='<tbody>';
        foreach($data as $weekData){
            $html.='<tr>';
            foreach($weekData as $wdi=>$day){
                $red = ($wdi == 5 || $wdi == 6)?1:0;
                $red = ($wdi == 5 || $wdi == 6);
                $cur = ($month_cur == $month && $day_cur == $day);
                $html.="<td data-red='$red' data-cur='$cur'>$day</td>";
            }
            $html.='</td>';
        }
        $html.='</tbody>';
        $html.='</table>';

        return $html;
    }

    $cdata = getCalendarData(2022,12);
    // print_r($cdata);

    ?>
    <style>
        .table td[data-red="1"]{
            color: red;
        }
        .table td[data-cur="1"]{
            background-color: #CCC;
        }
    </style>
    <div class="container text-center">
        <h1>2023</h1>
        <br>
        <div class="row">
            <? for($m=1; $m<=12; $m++): ?>
                <div class="col-4">
                    <?=printCalendar(2023,$m);?>
                </div>
            <? endfor; ?>
        </div>
    </div>
</body>
</html>