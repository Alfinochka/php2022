<?php
class Page{
    public $title;
    public $text;
    public function __construct($title,$text){
        [$this->title, $this->text] = [$title,$text];
    }
}