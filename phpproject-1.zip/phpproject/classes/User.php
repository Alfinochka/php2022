<?php
class User{
    public $name;
    public $status;
    public function __construct($name,$st){
        [$this->name, $this->status] = [$name,$st];
    }
}