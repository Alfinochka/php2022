<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <? $t0 = microtime(true); ?>
    <div class="playground">
        <? for($s=0; $s<=100; $s++): ?>
        <div class="row"><? for($i=0; $i<360; $i++): ?><div style="background-color: hsl(<?=$i?>, <?=$s?>%, 50%)" class="block"></div><? endfor; ?></div>
        <? endfor; ?>
        <? $t1  = microtime(true);?>
        
    </div>
    <p><? echo"Затрачено времени: ".($t1 - $t0); ?></p>
    <style>
        .row{
            height: 2px;
        }
        .playground .block{
            height: 2px;
            width: 1px;
            display: inline-block;
        }
    </style>
    <!-- , -->
</body>
</html>