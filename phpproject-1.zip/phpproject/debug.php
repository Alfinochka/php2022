<?php
session_start();
$a = ['a'=>'apple', 'b'=>'banana', 'c'=>['x','y','z']        ];
// echo"<pre>";
// print_r($a);
// var_dump($a);
// var_export($a);
// echo"</pre>";
// echo json_encode($a);
// echo "<script>console.log(".json_encode($a).")</script>";

class SomeClass{
    private $x = 100;
}

// $a = new SomeClass();
// echo"<pre>";
//     print_r($a);
//     var_dump($a);
//     var_export($a);
// echo"</pre>";

$arr = [3,1,7,6,9,4,12];

function cmp($a, $b){
    if($a == $b) return 0;
    return ($a < $b) ? -1 : 1;
    
}

usort($arr, function($a, $b){ return $a <=> $b; });

// print_r($arr);

//print_r($_SERVER);
if(isset($_SERVER['QUERY_STRING']) && false):
?>
Данные из строки адреса: <?=$_SERVER['QUERY_STRING']?>
<? endif; ?>

<?
// $_SESSION['COUNT']++;
// echo $_SESSION['COUNT'];
?>


<?

$var = ["123"];
// echo gettype($var);
switch(gettype($var)){
    case 'string':
        echo "Это была строка";
    break;
    case'integer':
        echo"Это было число";
    break;
    default:
        echo"Придетело НЛО и оставило эту запись";
    break;
}

?>