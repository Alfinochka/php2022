<?php
error_reporting(E_ALL);
ini_set('error_log','err.log');
ini_set('log_errors',true);
ini_set('display_errors',false);
$m = filemtime('spoon.txt');