<?php

function myErrorHandler($n, $message, $file, $line){
    echo "ER: ".error_reporting()."\r\n";
    echo "Ошибка #$n: $message \r\n".
    "В файле $file #$line";
}

set_error_handler('myErrorHandler',E_ALL);

@filemtime('e1.txt');