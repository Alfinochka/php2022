<?php

class fileSystemException extends Exception{
    private $name;
    public function __construct($name){
        $this->name = $name;
    }
    public function getName(){
        return $this->name;
    }
}

class fileNotFound extends fileSystemException{}
class fileNotWriteable extends fileSystemException{
    public function __construct($name){
        parent::__construct($name);
        throw new Error($name);
    }
}

function makeError(){
        try{
            $name = 'err0.log';
            if(!file_exists($name))
                throw new fileNotFound($name);
            // echo "$name is OK";
                throw new fileNotWriteable($name);//
        }catch(fileNotFound $e){
            echo "File not found: {$e->getName()}\r\n";
            // print_r($e->getTraceAsString());
            print $e;
        }catch(fileNotWriteable $e){
            echo "File not writeable: {$e->getName()}";
        }catch(Error $e){
            echo "Произошла мистическая ошибка \r\n";
        }

}

makeError();