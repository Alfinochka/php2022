<?php

try{
    echo 8 / "0";
}catch(Error $e){
    print_r($e);
}