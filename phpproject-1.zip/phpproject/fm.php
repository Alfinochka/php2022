<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Manager</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <?
        function formatSizeUnits($bytes)
        {
            if ($bytes >= 1073741824)
            {
                $bytes = number_format($bytes / 1073741824, 2) . ' GB';
            }
            elseif ($bytes >= 1048576)
            {
                $bytes = number_format($bytes / 1048576, 2) . ' MB';
            }
            elseif ($bytes >= 1024)
            {
                $bytes = number_format($bytes / 1024, 2) . ' KB';
            }
            elseif ($bytes > 1)
            {
                $bytes = $bytes . ' bytes';
            }
            elseif ($bytes == 1)
            {
                $bytes = $bytes . ' byte';
            }
            else
            {
                $bytes = '0 bytes';
            }
    
            return $bytes;
    }
    $dir = $_GET['dir'] ?? '.';
    $path = realpath($dir);
    // $dir = str_replace(__DIR__,'',$path);
    // $dir = $dir ?? '.';
    echo"dir: $dir; ";
    echo"path: $path; ";
    $data = [];
    $data['items'] = array_map(function($filename) use ($path){
        $is_dir = is_dir("$path/$filename");
        $root = __DIR__;
        return [
            'is_dir'=>$is_dir,
            'name'=>$filename,
            'size'=>filesize("$path/$filename"),
        ];
    },scandir($path));
    usort($data['items'],function($a,$b){
        if($a['is_dir'] != $b['is_dir']) return -($a <=> $b);
        return $a['name'] <=> $b['name'];
    });
    ?>
    <table class="table">
        <tbody>
            <? foreach($data['items'] as $item): ?>
                <?
                if($item['name'] == '.') continue;
                // $goto = 
                ?>
                <tr>
                    <td>
                        <? if($item['is_dir']): ?>
                    <a href="?dir=<?="$dir/{$item['name']}"?>"><?=$item['name']?></a>
                        <? else: ?>
                    <a href="fe.php?file=<?="$dir/{$item['name']}"?>"><?=$item['name']?></a>
                        <? endif; ?>
                    </td>
                    <td><?=($item['is_dir'])?'Папка':'Файл'?></td>
                    <td><?=formatSizeUnits($item['size'])?></td>
                </tr>
            <? endforeach; ?>
        </tbody>
    </table>
</body>
</html>