<?php

class MyIterableClass implements Iterator{
    private $i = 0;
    private $data = [
        'One','Two','Three','Four','Five',
    ];
    public function current(): mixed{ return $this->data[ $this->i ]; }
    public function key(): mixed{ return $this->i; }
    public function next(): void{ $this->i++; }
    public function rewind(): void{ $this->i=0; }
    public function valid(): bool{ return isset($this->data[ $this->i ]); }
}

$it = new MyIterableClass;
foreach($it as $one){
    echo "$one \r\n";
}