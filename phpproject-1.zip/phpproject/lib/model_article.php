<?php
trait IterableTrait{
    public function current(): mixed{ return $this->data[ $this->i ]; }
    public function key(): mixed{ return $this->i; }
    public function next(): void{ $this->i++; }
    public function rewind(): void{ $this->i=0; }
    public function valid(): bool{ return isset($this->data[ $this->i ]); }

}
class Model_Article implements Iterator{

    use IterableTrait;

    private $fields = ['ID','DATE','NAME','TEXT'];
    private $id = 0;
    private $loaded = false;
    private $itemData = [];
    private $dir = "/data/articles";
    protected $i = 0; 
    protected $data = [];

    public function __construct($id=null){
        if($id){
            $path = $_SERVER['DOCUMENT_ROOT'].$this->dir."/$id.json";
            if(file_exists($path)){
                $this->loaded = true;
                $this->itemData = json_decode(file_get_contents($path),true);
            }
        }
        if($this->loaded == false){
            $this->itemData = array_fill_keys($this->fields,null);
        }
    }
    public function __isset($key){
        return in_array($key,$this->fields);
    }
    public function __get($key){
        return $this->itemData[$key];
    }
    
    public function loaded(){
        return $this->loaded;
    }
    public function getList(){
        $arFileList = glob($_SERVER['DOCUMENT_ROOT'].$this->dir."/*.json");
        $arFileList = array_map(function($path){
            $json = file_get_contents($path);
            return $data = json_decode($json,true);
        },$arFileList);
        // $this->data = $arFileList;
        return $this->data = $arFileList;
    }
    public function asArray(){
        return $this->itemData;
    }
    public function getItem(){
        return [];
    }
    public function putItem($data){
        $path_dir = $_SERVER['DOCUMENT_ROOT'].$this->dir;
        if(!file_exists($path_dir)) mkdir($path_dir,0775,true);
        $id = ($this->id) ? $this->id : time();
        if(!isset($data['ID'])) $data['ID'] = $id;
        $path_file = $path_dir."/".$data['ID'].".json";
        $json = json_encode($data);
        file_put_contents($path_file, $json);
        return $this;
    }


}