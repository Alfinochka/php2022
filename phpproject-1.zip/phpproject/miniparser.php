<?php

if(empty($_SERVER['DOCUMENT_ROOT'])) $_SERVER['DOCUMENT_ROOT'] = __DIR__;

$text = '
    ... 
    <span></span>
    ...
    <div class="price">
        <span>35000</span>
    </div>
    ...
';
$stop1 = 'class="price';
$stop2 = '<span';
$stop3 = '>';
$stop4 = '<';

function seekTo($text,$what,$offset){
    return strpos($text,$what,$offset) + strlen($what);
}
function readTo($text,$what,$offset){
    $to = strpos($text,$what,$offset);
    return substr($text,$offset,$to - $offset);
}

$pos = 0;
// $pos = strpos($text,$stop1,$pos) + strlen($stop1);
// $pos = strpos($text,$stop2,$pos) + strlen($stop2);
// $pos = strpos($text,$stop3,$pos) + strlen($stop3);
// $pos = seekTo($text,$stop1,$pos);
// $pos = seekTo($text,$stop2,$pos);
// $pos = seekTo($text,$stop3,$pos);
// $to = strpos($text,$stop4,$pos);
// $val = substr($text,$pos,$to-$pos);
// $val = readTo($text,$stop4,$pos);

// echo "$pos\r\n";
// echo $val."\r\n";


class MiniParser{
    private $text;
    private $pos = 0;
    public function __construct($text){
        $this->text = $text;
    }
    public function seekTo($what){
        $this->pos = strpos($this->text, $what, $this->pos) + strlen($what);
        return $this;
    }
    public function readTo($what){
        $to = strpos($this->text, $what, $this->pos);
        return substr($this->text, $this->pos, $to - $this->pos);
    }
}
$mp = new MiniParser($text);
// $val = $mp->seekTo($stop1)
//     ->seekTo($stop2)
//     ->seekTo($stop3)
//     ->readTo($stop4);
// echo "val: ".$val."\r\n";
class MySuperClass{
    public $name;
    public function __construct($name){
        self::$value++;
        $this->name = $name;
    }
    public static $value = 0;
    public static function plusOne(){
        self::$value++;
    }
    public function __clone(){
        $this->name .=" (копия)";
    }
    public function __destruct(){
        // echo "class dead \r\n";
    }

    public function __toString(){
        return "Робот ".$this->name."\r\n";
    }

    // public function __sleep(){

    // }
}

class MyLogger{
    private $name;
    private $buffer='';
    public static $var="555";
    public function __construct($name){
        $this->name = $name;
    }
    public function log($data){
        // $this->buffer.="##\r\n# ".date('Y-m-d H:i:s')."\r\n##\r\n\r\n";
        $this->buffer.=print_r($data,true)."\r\n\r\n";
    }
    public function __destruct(){
        $dirpath = $_SERVER['DOCUMENT_ROOT'].'/log';
        if(!file_exists($dirpath)) mkdir($dirpath,0775,true);
        echo "$dirpath \r\n";
        $filepath = $dirpath.'/'.$this->name.'.log';
        $f = fopen($filepath, 'a');
        fputs($f,"##\r\n# ".date('Y-m-d H:i:s')."\r\n##\r\n\r\n");
        fputs($f,$this->buffer);
        // fputs($f,self::$var);
        fclose($f);
    }
}



// MySuperClass::plusOne();
// MySuperClass::plusOne();
// MySuperClass::plusOne();
// MySuperClass::plusOne();
// for($i=0; $i<5; $i++){
//     $msc[] = new MySuperClass();
// }
$msc = new MySuperClass("Фёдор");
$msc2 = clone $msc;
// $msc2->name = "Пётр";
// echo MySuperClass::$value."\r\n";
// print_r($msc);
// print_r($msc2);

// $r01 = serialize($msc);
// echo $r01;

echo $msc;

$log = new MyLogger('miniparser');
$log->log('All Done');
$log->log($msc2);