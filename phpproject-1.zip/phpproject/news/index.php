<? include_once $_SERVER['DOCUMENT_ROOT']."/func.php";?>
<?
    setTitle("Новости нашего городка");
    metaTitle("Новости нашего городка");
    metaData('title',"Новости нашего городка");
    $arItems = array(
        ['title'=>'Сегодня холодно','date'=>'2022-12-22'],
        ['title'=>'А в Саратове +3','date'=>'2022-12-21'],
    );
?>
<? include $_SERVER['DOCUMENT_ROOT']."/header.php" ?>
    <? if($arItems): ?>
    <ul>
        <? foreach($arItems as $arItem): ?>
            <li>
                <div>
                    <?=$arItem['date']?>
                    <?=($arItem['date']==date("Y-m-d"))?"// Сегодня":""?>
                </div>
                <div><?=$arItem['title']?></div>
            </li>
        <? endforeach; ?>
    </ul>
    <? else: ?>
        <h2>Сегодня новостей не будет</h2>
    <? endif; ?>
<? include $_SERVER['DOCUMENT_ROOT']."/footer.php" ?>
