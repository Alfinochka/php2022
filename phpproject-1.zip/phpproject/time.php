<?php
// echo date_default_timezone_get();
echo date("Y-m-d H:i:s");