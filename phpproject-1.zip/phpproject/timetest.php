<?php

$t = microtime(true);
$n = 1000000;
$a = 0;
//$x
for($i=0; $i<$n; $i++ ){
    $a++;
}
$tt = microtime(true) - $t;
echo "tt = ".number_format($tt);