<?php

trait A{
    function sayHello(){
        echo "Hello ";
    }
}
trait C{
    function sayName(){
        echo "World ";
    }
}
class B{
    use A, C;
}

// $cb = new B;
// $cb->sayHello();
// $cb->sayName();

class Base{
    public function sayHello(){
        echo "Hello ";
    }
}

trait World{
    public function sayHello(){
        parent::sayHello();
        echo "World ";
    }
}

class HelloWorld extends Base{
    use World;
    public function sayHello(){
        echo "Ы \r\n";
    }
}

$hw = new HelloWorld;
$hw->sayHello();




trait Hello{
    public function sayHello(){
        echo "Hello ";
    }
}
trait Wordle{
    public function sayName(){
        echo "Wordle =) \r\n";
    }
}
trait HelloWordle{
    use Hello, Wordle;
}
class MyHelloWordle{
    use HelloWordle;
}

$mhw = new MyHelloWordle();
$mhw->sayHello();
$mhw->sayName();