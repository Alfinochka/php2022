<?php

include 'lib/PHP8.php';

// echo PHP8\strlen("Привет мир");
use PHP8\Page as Superpage;

$p = new Superpage();